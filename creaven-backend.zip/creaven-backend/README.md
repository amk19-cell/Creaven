# Creaven — Backend emails & paiement

## Structure
```
functions/api/          → Cloudflare Pages Functions (à mettre à la racine du repo Creaven, dossier "functions/")
  _email-templates.js   → templates HTML des 4 emails
  _resend.js            → envoi via l'API Resend
  _firestore.js         → accès Firestore REST (compte de service)
  send-signup-email.js  → POST /api/send-signup-email
  send-booking-email.js → POST /api/send-booking-email
  send-payment-email.js → POST /api/send-payment-email (usage interne, voir note dans le fichier)
  paystack-webhook.js   → POST /api/paystack-webhook (déclenché par Paystack, PAS par le client)

reminder-worker/        → Worker Cloudflare SÉPARÉ, avec Cron Trigger (déploiement indépendant)
  src/index.js
  wrangler.toml
```

## 1. Déployer les Pages Functions
1. Copie le dossier `functions/` à la racine de ton repo `Creaven` (à côté de `index.html`).
2. Cloudflare Pages détecte automatiquement `functions/` et déploie les routes `/api/*`.
3. Dans le dashboard Cloudflare Pages → ton projet Creaven → **Settings → Environment variables**, ajoute en **secret** :
   - `RESEND_API_KEY`
   - `PAYSTACK_SECRET_KEY`
   - `FIREBASE_SERVICE_ACCOUNT` (le JSON complet du compte de service Firebase, en une seule ligne — voir ci-dessous)

## 2. Obtenir le compte de service Firebase
Firebase Console → ⚙️ Paramètres du projet → **Comptes de service** → "Générer une nouvelle clé privée" → télécharge le JSON.
Colle tout le contenu de ce fichier JSON (aplati en une ligne) comme valeur de `FIREBASE_SERVICE_ACCOUNT`.
⚠️ Ce fichier donne un accès total à Firestore — ne jamais le committer sur GitHub, ne jamais l'envoyer en clair dans un chat.

## 3. Configurer le webhook Paystack
Dashboard Paystack → Settings → API Keys & Webhooks → Webhook URL :
```
https://creaven.pages.dev/api/paystack-webhook
```
C'est cet endpoint, et lui seul, qui doit marquer une commande comme payée — jamais un appel direct du navigateur.

## 4. Rappels de rendez-vous — DEUX OPTIONS (choisis-en une seule)

### Option A — Tu as un ordinateur/terminal : Worker séparé avec Cron Trigger
```bash
cd reminder-worker
npm install -g wrangler
wrangler login
wrangler secret put RESEND_API_KEY
wrangler secret put FIREBASE_SERVICE_ACCOUNT
wrangler deploy
```
Le Cron Trigger (`*/15 * * * *` dans `wrangler.toml`) tourne automatiquement toutes les 15 min une fois déployé.

### Option B — Pas d'ordinateur/terminal : cron-job.org (gratuit, tout depuis le navigateur)
Rien à installer. La route `functions/api/run-reminders.js` fait exactement la même chose que le Worker, mais se déploie automatiquement avec le reste de `functions/` quand tu uploades sur GitHub.
1. Dans Cloudflare Pages → ton projet → Environment variables, ajoute un secret `REMINDERS_CRON_TOKEN` avec une valeur aléatoire longue (génère-en une sur uuidgenerator.net)
2. Crée un compte gratuit sur https://cron-job.org
3. "Create cronjob" → URL : `https://creaven.pages.dev/api/run-reminders?token=TON_TOKEN_SECRET` (remplace par la même valeur qu'à l'étape 1)
4. Intervalle : toutes les 15 minutes → Sauvegarde
5. C'est tout — tu peux ignorer complètement le dossier `reminder-worker/` dans ce cas

**Ne fais qu'une seule des deux options**, pas les deux (sinon rappels envoyés en double).

## 5. Ce qu'il reste à câbler côté frontend
Ces fonctions attendent d'être appelées depuis ton code JS existant :
- Après un `createUserWithEmailAndPassword` réussi → `fetch('/api/send-signup-email', {method:'POST', body: JSON.stringify({to, name, lang})})`
- Réservation d'un rendez-vous gratuit/inclus : appelle `/api/create-appointment` (retourne `sessionCode`), puis `/api/send-booking-email` avec ces infos.
- Réservation/achat payant : appelle `/api/create-order` (retourne `orderId`) → utilise cet `orderId` dans les `metadata` de l'initialisation Paystack côté client (voir commentaire dans `create-order.js`) → le webhook Paystack se charge du reste automatiquement.
- Les rappels sont automatiques via le Worker — nécessite que chaque document `appointments` créé via `/api/create-appointment` ait bien les champs attendus (déjà le cas avec cet endpoint).

## Nouveaux endpoints ajoutés
- `create-appointment.js` → POST, crée le doc `appointments` + génère le code de session à 6 caractères
- `create-order.js` → POST, crée le doc `orders` en status "pending" avant paiement Paystack

## Non fait dans cette passe (à prévoir)
- Gestion PayPal (actuellement seul Paystack est géré par le webhook)
- Tests réels avec de vraies clés — tout ceci n'a pas pu être testé en conditions réelles, seulement vérifié syntaxiquement
