// Worker Cloudflare séparé (PAS une Pages Function) — tourne sur un Cron Trigger.
// Toutes les X minutes : interroge Firestore pour les rendez-vous dont
// l'heure de rappel est passée mais qui n'ont pas encore été notifiés,
// envoie l'email de rappel via Resend, puis marque le document comme
// "reminderSent" pour ne jamais rappeler deux fois.
//
// Déploiement : `wrangler deploy` depuis le dossier reminder-worker/
// Variables secrètes requises (via `wrangler secret put <NOM>`) :
//   RESEND_API_KEY
//   FIREBASE_SERVICE_ACCOUNT

import { appointmentReminderEmail } from "./_email-templates.js";
import { sendEmail } from "./_resend.js";
import { runFirestoreQuery, updateFirestoreDoc } from "./_firestore.js";

// Combien de minutes avant le rdv le rappel doit partir.
const REMINDER_MINUTES_BEFORE = 60;

function extractValue(field) {
  if (!field) return undefined;
  const key = Object.keys(field)[0];
  return field[key];
}

export default {
  async scheduled(event, env, ctx) {
    ctx.waitUntil(processReminders(env));
  },

  // Permet aussi un déclenchement manuel via requête HTTP pour tester
  // (ex: https://creaven-reminders.<ton-sous-domaine>.workers.dev/)
  async fetch(request, env) {
    await processReminders(env);
    return new Response("Rappels traités.", { status: 200 });
  },
};

async function processReminders(env) {
  const now = new Date();
  const windowEnd = new Date(now.getTime() + REMINDER_MINUTES_BEFORE * 60000);

  // Cherche les rendez-vous dont startTime tombe dans la fenêtre
  // [maintenant, maintenant + 60min] et qui n'ont pas encore reçu de rappel.
  // Suppose une collection "appointments" avec les champs :
  //   startTime (timestamp), reminderSent (bool), status ("confirmed"),
  //   email, name, sessionCode, lang
  const structuredQuery = {
    from: [{ collectionId: "appointments" }],
    where: {
      compositeFilter: {
        op: "AND",
        filters: [
          {
            fieldFilter: {
              field: { fieldPath: "startTime" },
              op: "GREATER_THAN_OR_EQUAL",
              value: { timestampValue: now.toISOString() },
            },
          },
          {
            fieldFilter: {
              field: { fieldPath: "startTime" },
              op: "LESS_THAN_OR_EQUAL",
              value: { timestampValue: windowEnd.toISOString() },
            },
          },
          {
            fieldFilter: {
              field: { fieldPath: "reminderSent" },
              op: "EQUAL",
              value: { booleanValue: false },
            },
          },
          {
            fieldFilter: {
              field: { fieldPath: "status" },
              op: "EQUAL",
              value: { stringValue: "confirmed" },
            },
          },
        ],
      },
    },
  };

  let results;
  try {
    results = await runFirestoreQuery(env, structuredQuery);
  } catch (err) {
    console.error("Erreur requête Firestore:", err.message);
    return;
  }

  const docs = (results || []).filter((r) => r.document);
  if (docs.length === 0) {
    console.log("Aucun rappel à envoyer pour ce cycle.");
    return;
  }

  for (const item of docs) {
    const doc = item.document;
    const docId = doc.name.split("/").pop();
    const f = doc.fields || {};

    const email = extractValue(f.email);
    const name = extractValue(f.name);
    const sessionCode = extractValue(f.sessionCode);
    const lang = extractValue(f.lang) || "en";
    const startTime = extractValue(f.startTime);

    if (!email || !sessionCode || !startTime) {
      console.error(`Document ${docId} incomplet, rappel ignoré.`);
      continue;
    }

    const dateTimeLabel = new Date(startTime).toLocaleString(lang === "fr" ? "fr-FR" : "en-US", {
      dateStyle: "medium",
      timeStyle: "short",
    });

    try {
      const { subject, html } = appointmentReminderEmail({
        name,
        dateTimeLabel,
        sessionCode,
        minutesBefore: REMINDER_MINUTES_BEFORE,
        lang,
      });
      await sendEmail(env, { to: email, subject, html });

      // Marque comme envoyé pour ne jamais dupliquer le rappel.
      await updateFirestoreDoc(env, "appointments", docId, { reminderSent: true });
      console.log(`Rappel envoyé pour ${docId} (${email}).`);
    } catch (err) {
      console.error(`Échec d'envoi du rappel pour ${docId}:`, err.message);
    }
  }
}
